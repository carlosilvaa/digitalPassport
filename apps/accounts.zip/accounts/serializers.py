# apps/accounts/serializers.py
from rest_framework import serializers
from apps.accounts.models import User

class UserSerializer(serializers.Serializer):
    id          = serializers.CharField(read_only=True)
    full_name   = serializers.CharField()
    email       = serializers.EmailField()
    address     = serializers.CharField(required=False, allow_null=True, allow_blank=True)
    nif         = serializers.CharField(required=False, allow_null=True, allow_blank=True)
    niss        = serializers.CharField(required=False, allow_null=True, allow_blank=True)
    is_company  = serializers.BooleanField()
    is_superuser= serializers.BooleanField()
    is_active   = serializers.BooleanField()

class RegisterSerializer(serializers.Serializer):
    full_name   = serializers.CharField()
    email       = serializers.EmailField()
    password    = serializers.CharField(write_only=True)
    address     = serializers.CharField(required=False, allow_blank=True, allow_null=True)
    nif         = serializers.CharField(required=False, allow_blank=True, allow_null=True)
    niss        = serializers.CharField(required=False, allow_blank=True, allow_null=True)
    is_company  = serializers.BooleanField(required=False, default=False)

    # >>> Faça a unicidade aqui (durante is_valid)
    def validate_email(self, value):
        value = (value or "").strip().lower()
        if User.objects(email=value).first():
            raise serializers.ValidationError("Já existe um utilizador com este e-mail.")
        return value

    def validate(self, attrs):
        # quaisquer outras regras transversais você pode colocar aqui,
        # ex.: exigir um entre NIF/NISS (se não fez na view)
        return attrs

    def create(self, validated_data):
        # ATENÇÃO: não levante ValidationError aqui por e-mail duplicado,
        # já fizemos em validate_email.
        pwd = validated_data.pop("password")
        u = User(**validated_data)
        u.set_password(pwd)
        u.is_active = True
        u.save()
        return u


class LoginSerializer(serializers.Serializer):
    email    = serializers.EmailField()
    password = serializers.CharField(write_only=True)
